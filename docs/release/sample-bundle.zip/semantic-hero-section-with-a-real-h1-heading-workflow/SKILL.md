---
name: semantic-hero-section-with-a-real-h1-heading-workflow
description: Workflow learned from "Accessible hero sections"
---

# Semantic hero section with a real h1 heading workflow

Workflow learned from "Accessible hero sections"

## When to use this skill

- When the task matches: Workflow learned from "Accessible hero sections"

## Workflow

1. **Create a semantic hero section with a real h1 heading** (build) — Create a semantic hero section with a real h1 heading
2. **Wrap the visible content in a main landmark** (build) — Wrap the visible content in a main landmark
3. **Add pill-shaped call-to-action buttons with visible focus states** (build) — Add pill-shaped call-to-action buttons with visible focus states
4. **Check color contrast against WCAG AA before shipping** (verification) — Check color contrast against WCAG AA before shipping

## Guardrails

- Stop and ask a human before any consequential or irreversible action.

## Verification

- Skill graph is structurally valid (graph, blocking)
- Artifact hashes recompute (hash, blocking)
- No unresolved placeholder markers (policy, blocking)

Run `node scripts/verify.mjs` from the bundle root to check bundle integrity.

## Reference material

- `references/evidence.md` — the evidence and provenance this skill was learned from.
- `references/memory-policy.md` — memory scopes this skill may read and propose.
- `policies/safety.md` — safety rules that always apply.
- `policies/originality.md` — source-material and copying rules.
- `evals/acceptance-tests.json` — machine-readable acceptance assertions.

_Compiled by Cherry from SkillGraph sg-01M17T5M9CE17Y0MB1K5W2ZKYY v0.1.0 r2. Evidence records: 4. Approved memories referenced: 0._