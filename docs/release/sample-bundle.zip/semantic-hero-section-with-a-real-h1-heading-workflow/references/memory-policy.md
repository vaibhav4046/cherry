# Memory policy

Allowed scopes: mission, workspace
Allowed sensitivity: public, private
New memory always requires explicit human approval before it takes effect.

## Approved memories referenced by this skill

_None._