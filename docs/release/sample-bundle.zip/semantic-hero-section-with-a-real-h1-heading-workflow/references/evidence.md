# Evidence ledger

All source material starts untrusted; trust shown here was set by a person.

## Create a semantic hero section with a real h1 heading

- Source type: transcript
- Timestamp: 5s
- Provenance: user_typed
- Trust: untrusted
- Confidence: 0.5
- Transferability: unknown

## Wrap the visible content in a main landmark

- Source type: transcript
- Timestamp: 40s
- Provenance: user_typed
- Trust: untrusted
- Confidence: 0.5
- Transferability: unknown

## Add pill-shaped call-to-action buttons with visible focus states

- Source type: transcript
- Timestamp: 70s
- Provenance: user_typed
- Trust: untrusted
- Confidence: 0.5
- Transferability: unknown

## Check color contrast against WCAG AA before shipping

- Source type: transcript
- Timestamp: 110s
- Provenance: user_typed
- Trust: untrusted
- Confidence: 0.5
- Transferability: unknown
