# Originality policy

- Learn transferable principles from permitted sources; never clone branding, assets, or exact copy.
- Keep source attributions in references/evidence.md.
- YouTube lessons use the official visible player only; no captions or media are scraped or re-hosted.
