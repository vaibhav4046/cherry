# Approval policy

This skill was approved by user at revision 2.
Any edit to the skill graph invalidates that approval and requires a new one.
- Gate: Approve this skill before execution (approve) — Execution requires an exact-revision human approval
