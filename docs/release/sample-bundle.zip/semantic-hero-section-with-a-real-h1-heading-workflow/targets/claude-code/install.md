# Install into Claude Code

1. Copy the `semantic-hero-section-with-a-real-h1-heading-workflow` bundle into `.claude/skills/semantic-hero-section-with-a-real-h1-heading-workflow` in your
   project (or `~/.claude/skills/` for all projects).
2. Claude Code discovers `SKILL.md` by its frontmatter name and description.
3. Optionally merge `targets/claude-code/hooks.example.json` into your
   `.claude/settings.json` to remind the agent about approvals.
4. Verify the bundle first: `node scripts/verify.mjs` from the bundle root.
