# Semantic hero section with a real h1 heading workflow — Codex target

Workflow learned from "Accessible hero sections"

## Instructions

Follow the workflow in `../../SKILL.md`. Honour every human gate: stop and
ask the user before any step marked as requiring approval.

## Verification

After completing the workflow, run the acceptance assertions listed in
`../../evals/acceptance-tests.json`. Completion without those checks is not
verification.
