# Install into Codex

1. Copy the `semantic-hero-section-with-a-real-h1-heading-workflow` bundle directory into your project.
2. Append the contents of `targets/codex/AGENTS.md` to your project `AGENTS.md`,
   or reference it from there.
3. Codex reads `AGENTS.md` from the project root automatically.
4. Verify the bundle first: `node scripts/verify.mjs` from the bundle root.

This target works where your Codex setup supports project instructions; it
does not grant Codex any tool the host does not already provide.
