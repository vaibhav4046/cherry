#!/usr/bin/env node
// Cherry bundle verifier: recomputes MANIFEST.json SHA-256 hashes and the
// receipt hash (RFC 8785 canonical JSON). Exits non-zero on any mismatch.
import { createHash } from 'node:crypto';
import { readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = dirname(fileURLToPath(import.meta.url)) + '/..';

function sha256(buffer) {
  return createHash('sha256').update(buffer).digest('hex');
}

function canonicalize(value) {
  if (value === null) return 'null';
  const type = typeof value;
  if (type === 'boolean') return value ? 'true' : 'false';
  if (type === 'number') {
    if (!Number.isFinite(value)) throw new TypeError('non-finite number');
    return Object.is(value, -0) ? '0' : String(value);
  }
  if (type === 'string') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map((item) => canonicalize(item === undefined ? null : item)).join(',') + ']';
  if (type === 'object') {
    const keys = Object.keys(value).filter((key) => value[key] !== undefined).sort();
    return '{' + keys.map((key) => JSON.stringify(key) + ':' + canonicalize(value[key])).join(',') + '}';
  }
  throw new TypeError('cannot canonicalize ' + type);
}

let failures = 0;

const manifestPath = join(root, 'MANIFEST.json');
if (!existsSync(manifestPath)) {
  console.error('FAIL: MANIFEST.json missing');
  process.exit(1);
}
const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
for (const [file, expected] of Object.entries(manifest.files)) {
  const filePath = join(root, file);
  if (!existsSync(filePath)) {
    console.error('FAIL: listed file missing: ' + file);
    failures += 1;
    continue;
  }
  const actual = sha256(readFileSync(filePath));
  if (actual !== expected) {
    console.error('FAIL: hash mismatch for ' + file);
    console.error('  expected ' + expected);
    console.error('  actual   ' + actual);
    failures += 1;
  } else {
    console.log('ok ' + file);
  }
}

const receiptPath = join(root, 'receipt.json');
if (existsSync(receiptPath)) {
  const receipt = JSON.parse(readFileSync(receiptPath, 'utf8'));
  const stored = receipt.receiptHash;
  const clone = JSON.parse(JSON.stringify(receipt));
  for (const exclusion of receipt.canonicalization?.exclusions ?? ['receiptHash']) {
    delete clone[exclusion];
  }
  const recomputed = sha256(Buffer.from(canonicalize(clone), 'utf8'));
  if (recomputed !== stored) {
    console.error('FAIL: receipt hash mismatch');
    console.error('  stored     ' + stored);
    console.error('  recomputed ' + recomputed);
    failures += 1;
  } else {
    console.log('ok receipt.json hash (tamper-evident, not a signature)');
  }
}

if (failures > 0) {
  console.error(failures + ' verification failure(s)');
  process.exit(1);
}
console.log('Bundle verification passed');
